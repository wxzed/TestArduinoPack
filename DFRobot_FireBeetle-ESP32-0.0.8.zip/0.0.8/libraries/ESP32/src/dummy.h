// This file is here only to silence warnings from Arduino IDE
// Currently IDE doesn't support no-code libraries, like this collection of example sketches.
